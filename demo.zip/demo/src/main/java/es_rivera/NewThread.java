package es_rivera;

public class NewThread extends Thread {
    
    public void stampaThread(){
        System.out.println("\nStampa Thread");
        for (int i = 0; i < 10; i++ ) {
            System.out.print(i + " - ");
        }
    }

    @Override
    public void run() {
        stampaThread();
    }

}
