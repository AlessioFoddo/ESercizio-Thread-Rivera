package es_rivera;

public class Main {
    public static void main(String[] args) {

        NewThread th1 = new NewThread();

        System.out.println("Stampa main");

        for(int i = 0; i < 10; i++){
            System.out.print(i + " - ");
        }

        th1.run();

    }
}